# Xtream-UI Ubuntu 20.04
Install Xtream-UI R22 on Ubuntu 20.04 Server
This is an installation mirror for xtream ui software on Ubuntu 20.04. Includes NGINX 1.19.2 and PHP 7.3.25.

### Installation: ###

Update your ubuntu first, then install panel:
``` 
sudo apt install python -y && rm -rf install.py && wget https://github.com/haremmahmud/Xtream-UI-Ubuntu20.04/raw/main/install.py && sudo python3 install.py 
```
